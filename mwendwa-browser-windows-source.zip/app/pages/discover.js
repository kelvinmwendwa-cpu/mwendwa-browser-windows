(function(){
'use strict';
const $=id=>document.getElementById(id);
const allowedRegions=['KE','US','GB','NG','ZA'];
const categories={
 trending:{tag:'SEARCH INTEREST',title:'Trending right now',note:'Explore Google’s trending searches for your selected country. Search interest is not a measure of accuracy.',link:'Open Google Trends ↗',section:'TRENDING SEARCHES',url:()=>`https://trends.google.com/trending?geo=${region}`},
 news:{tag:'LATEST HEADLINES',title:'Stay in the know',note:'Fresh headlines from publishers indexed by Google News. Tap a headline to open the article and check its publication time.',link:'Open Google News ↗',section:'LATEST NEWS',url:()=>`https://news.google.com/home?hl=en-${region}&gl=${region}&ceid=${region}:en`},
 movies:{tag:'LIVE SOURCE CHART',title:'What’s popular in film',note:'Open IMDb’s Most Popular Movies chart for its current rankings. The headlines below cover recent movie news and trailers.',link:'Open IMDb movie chart ↗',section:'RECENT MOVIE HEADLINES',url:()=> 'https://www.imdb.com/chart/moviemeter/'},
 music:{tag:'LIVE SOURCE CHART',title:'Find your next favourite',note:'YouTube Charts has current song and music-video rankings. Choose the country and chart period on its site. Headlines below cover recent music news.',link:'Open YouTube Charts ↗',section:'RECENT MUSIC HEADLINES',url:()=> 'https://charts.youtube.com/'},
 tiktok:{tag:'LIVE SOURCE DASHBOARD',title:'Catch the next trend',note:'Open TikTok’s trend dashboard for its latest available trends and region filters. The headlines below are TikTok news, not a scraped ranking of viral videos.',link:'Open TikTok trends ↗',section:'TIKTOK NEWS & CULTURE',url:()=> 'https://ads.tiktok.com/creative/creativeCenter/trends'}
};
let region='KE',category='trending',data=null,request=0,controller=null,nativePaused=false;
try{const saved=localStorage.getItem('mwendwa-discover-region');if(allowedRegions.includes(saved))region=saved;}catch(e){}
$('region').value=region;
function time(n){return new Date(n).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});}
function key(){return 'mwendwa-discover-v1:'+region+':'+category;}
function readCache(){try{const cached=JSON.parse(localStorage.getItem(key()));return cached&&cached.region===region&&cached.category===category&&Array.isArray(cached.items)?cached:null;}catch(e){return null;}}
function status(message,error){$('status').textContent=message;$('status').className='status'+(error?' error':'');}
function draw(){
 $('stories').replaceChildren();if(!data)return;
 data.items.slice(0,24).forEach(item=>{let url;try{url=new URL(item.url);}catch(e){return;}if(url.protocol!=='https:'||url.username||url.password)return;
 const li=document.createElement('li'),a=document.createElement('a'),title=document.createElement('h3'),meta=document.createElement('div');
 a.href=url.href;a.className='story';title.textContent=item.title;meta.className='meta';
 const details=[item.publisher];if(item.published){const date=Date.parse(item.published);details.push(Number.isFinite(date)?new Date(date).toLocaleString():item.published);}meta.textContent=details.filter(Boolean).join(' · ');
 a.append(title,meta);if(category==='trending'&&item.traffic){const traffic=document.createElement('div');traffic.className='meta traffic';traffic.textContent=item.traffic+' searches · source estimate';a.append(traffic);}li.append(a);$('stories').append(li);
 });
}
function choose(){const config=categories[category];$('feature-tag').textContent=config.tag;$('feature-title').textContent=config.title;$('feature-note').textContent=config.note;$('feature-link').textContent=config.link;$('feature-link').href=config.url();$('source-link').href=config.url();$('source-link').textContent=config.link;$('section-title').textContent=config.section;document.querySelectorAll('[data-category]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.category===category)));data=readCache();draw();refresh();}
async function refresh(){
 if(document.hidden||nativePaused)return;
 const id=++request;if(controller)controller.abort();controller=new AbortController();status(data?'Refreshing · previously fetched '+time(data.fetchedAt):'Connecting to the live source…');$('refresh').textContent='↻ Updating…';
 try{const response=await fetch('/discover/feed?category='+encodeURIComponent(category)+'&region='+encodeURIComponent(region)+'&t='+Date.now(),{cache:'no-store',signal:controller.signal});if(!response.ok)throw Error('Source unavailable');const result=await response.json();if(id!==request)return;if(result.category!==category||result.region!==region||!Array.isArray(result.items)||!result.items.length||!Number.isFinite(result.fetchedAt))throw Error('Invalid source response');data=result;try{localStorage.setItem(key(),JSON.stringify(data));}catch(e){}draw();status('Fetched '+time(data.fetchedAt)+' · '+data.source+(data.sourceUpdated?' · source updated '+data.sourceUpdated:''));
 }catch(e){if(id!==request||e.name==='AbortError')return;status(data?'Could not refresh · showing cached results fetched '+time(data.fetchedAt):'Live feed unavailable. Check your internet, retry, or open the source above.',true);if(!data){$('stories').replaceChildren();const li=document.createElement('li');li.className='empty';li.textContent='No live results were retrieved. The source chart links remain available.';$('stories').append(li);}}
 finally{if(id===request)$('refresh').textContent='↻ Refresh';}
}
$('region').addEventListener('change',()=>{region=$('region').value;try{localStorage.setItem('mwendwa-discover-region',region);}catch(e){}choose();});
document.querySelectorAll('[data-category]').forEach(b=>b.addEventListener('click',()=>{category=b.dataset.category;choose();}));
$('refresh').addEventListener('click',refresh);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
window.addEventListener('mwendwa-hide',()=>{nativePaused=true;});window.addEventListener('mwendwa-show',()=>{nativePaused=false;refresh();});
setInterval(()=>{if(!document.hidden&&!nativePaused)refresh();},300000);
choose();
}());
