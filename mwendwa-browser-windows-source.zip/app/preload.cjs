const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('mwendwa',{command:(action,data)=>ipcRenderer.invoke('browser',action,data),onState:fn=>ipcRenderer.on('state',(_event,value)=>fn(value)),onNotice:fn=>ipcRenderer.on('notice',(_event,value)=>fn(value)),onFocusAddress:fn=>ipcRenderer.on('focus-address',()=>fn()),onFind:fn=>ipcRenderer.on('show-find',()=>fn())});
