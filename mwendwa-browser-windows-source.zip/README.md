# Mwendwa Browser for Windows 1.0

Install MwendwaBrowser-Windows-Setup-1.0.0-x64.exe on a 64-bit Windows 10/11 laptop. The installer includes its browser runtime, installs for the current Windows user, creates desktop/Start menu shortcuts, and adds a Windows uninstall entry. Close a running copy before installing updates. Internet is needed for websites, source charts and streaming.

This is an unsigned first release. Windows may display an unknown-publisher notice. The Windows installer has not been executed on a Windows machine; the app was smoke-tested with the Linux Electron runtime in a headless environment.

## Features

- Twelve tabs, address/search field, bookmark and history storage, downloads through a save dialog, find in page and zoom. Ctrl+L, Ctrl+T, Ctrl+W, Ctrl+F, Ctrl+R and Alt+Left/Right shortcuts.
- Navy/gold Mwendwa crest on the app and installer.
- Default ad/tracker host blocking with global and per-site controls; blocks popup windows. Long press/right click a link to open a new tab. The optional YouTube helper hides known banners and clicks available skip buttons; it does not guarantee ad-free video playback.
- Discover: live Google Trends/News feeds and source chart links. Feed fetch times and cached/offline states are labelled. Movie, music and TikTok headlines are news, not scraped popularity rankings.
- Free Movies: source-listed public-domain/CC0 MP4 catalog, cached searches and a dedicated player page with standard video controls. Catalogue completeness, source availability, licence labels and streaming speed are controlled by the provider. No promise of every film or every recent release.
- Deep Search: ten public search sources including Google, Bing, DuckDuckGo, Brave, Scholar, Semantic Scholar, arXiv, Wikipedia, Internet Archive and YouTube. Exact phrases, exclusions, up to five website domains, file filters, country bias, Google date/type filters, query preview and twelve saved searches. Open up to four selected sources as tabs. Academic/reference sources use topic and exact phrase; provider support for other operators varies. It constructs searches and opens their results; it does not produce an AI-written research report.

## Privacy and compatibility

Browser history, bookmarks, cookies, tab URLs and saved queries are stored in Windows app data. Search terms are sent to the engines you open. Discover requests public Google feeds. Movie search, thumbnails (only when enabled) and streaming use Internet Archive. Clear browsing data closes tabs, removes cookies/history/site storage/saved Deep Searches and keeps bookmarks and downloaded files. Website camera, microphone, location and device permissions are denied.

Remote pages run without Node.js integration or a preload bridge, with context isolation, sandbox settings and web security enabled. The browser toolbar has a separately validated IPC interface and a separate local origin/session. This is not an independently audited browser. No automatic updater, extension store, password manager or isolated incognito mode is included. Some provider sign-ins, DRM services and advanced websites may require another browser.

## Rebuild

Use Node.js 22 or newer: `npm ci`, then `npm start`. `npm test` runs query, parser and source-validation checks. `npm run dist:win` packages the Windows x64 runtime and compiles an NSIS installer. It works from Windows or Linux and downloads checksum-verified packaging tools. Exact package versions are in package-lock.json.

The build uses Electron 45.0.0, a pure JavaScript PE-resource branding hook, ASAR packaging and a native NSIS installer. The custom installer avoids requiring Wine to generate an uninstaller at build time: WriteUninstaller runs during Windows installation. Uninstallation deletes the known shipped files and empty directories rather than recursively removing unrelated files. Browser profile data is preserved.

## Validation

- Query construction/provider scoping, source URL and date/domain validation, movie/MP4 licence guards, XML DTD rejection and stream selection tests.
- Deep Search UI tested at 320, 393 and 1280-pixel widths; saved-search restore/delete, selection limit and safe text rendering.
- Real Electron smoke test: shell/protocol loading, sandboxed guest without require or a toolbar bridge, Deep Search query building, menu view layout and opening multiple source tabs. Linux test invocation required no-sandbox in the container; packaged production preferences retain sandbox settings.
- Windows app verified as x64 PE with Mwendwa icon/version resources and required ASAR files. NSIS installer successfully compiled, including uninstall code. Production dependency audit reported no advisories at build time.
- Windows installation, Windows media playback and OS integration still need testing on Windows.

## Notices

Electron and Chromium licence files are included with the packaged runtime. Runtime dependencies carry their own notices. AdAway default hosts list is included unmodified with its original attribution header, licensed CC Attribution 3.0: https://creativecommons.org/licenses/by/3.0/. Source: https://github.com/AdAway/adaway.github.io/. The Mwendwa crest is an original code-drawn asset created for this project.
