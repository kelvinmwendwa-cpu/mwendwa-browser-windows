'use strict';
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const {getMakeNsisPath}=require('app-builder-lib/out/toolsets/windows');
(async()=>{const root=__dirname,appDir=path.join(root,'dist/win-unpacked'),output=path.join(root,'dist/MwendwaBrowser-Windows-Setup-1.0.0-x64.exe');if(!fs.existsSync(path.join(appDir,'Mwendwa Browser.exe')))throw Error('Build the unpacked Windows app first.');const files=[],dirs=[];function walk(dir,rel=''){for(const d of fs.readdirSync(dir,{withFileTypes:true})){const r=path.join(rel,d.name);if(d.isDirectory()){dirs.push(r);walk(path.join(dir,d.name),r);}else files.push(r);}}walk(appDir);const esc=s=>s.replace(/\$/g,'$$').replace(/"/g,'$\\"');const windows=s=>s.split(path.sep).join('\\');
const deletes=files.map(f=>'  Delete "$INSTDIR\\'+esc(windows(f))+'"').join('\n');const removeDirs=dirs.sort((a,b)=>b.split(path.sep).length-a.split(path.sep).length).map(d=>'  RMDir "$INSTDIR\\'+esc(windows(d))+'"').join('\n');
const script=`Unicode true
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "x64.nsh"
!include "WinVer.nsh"
Name "Mwendwa Browser"
OutFile "${esc(output)}"
InstallDir "$LOCALAPPDATA\\Programs\\Mwendwa Browser"
InstallDirRegKey HKCU "Software\\MwendwaBrowser" "InstallDir"
RequestExecutionLevel user
SetCompressor /SOLID lzma
SetCompressorDictSize 32
VIProductVersion "1.0.0.0"
VIAddVersionKey /LANG=1033 "ProductName" "Mwendwa Browser"
VIAddVersionKey /LANG=1033 "FileDescription" "Mwendwa Browser Setup"
VIAddVersionKey /LANG=1033 "FileVersion" "1.0.0"
VIAddVersionKey /LANG=1033 "LegalCopyright" "Mwendwa"
!define MUI_ICON "${esc(path.join(root,'assets/icon.ico'))}"
!define MUI_UNICON "${esc(path.join(root,'assets/icon.ico'))}"
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\\Mwendwa Browser.exe"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
Function .onInit
  \${IfNot} \${RunningX64}
    MessageBox MB_ICONSTOP "Mwendwa Browser requires 64-bit Windows 10 or Windows 11."
    Abort
  \${EndIf}
  \${IfNot} \${AtLeastWin10}
    MessageBox MB_ICONSTOP "Mwendwa Browser requires Windows 10 or newer."
    Abort
  \${EndIf}
  FindWindow $0 "Chrome_WidgetWin_1" "Mwendwa Browser"
  \${If} $0 != 0
    MessageBox MB_ICONINFORMATION "Close Mwendwa Browser before installing this update."
    Abort
  \${EndIf}
FunctionEnd
Section "Mwendwa Browser"
  SetShellVarContext current
  SetOutPath "$INSTDIR"
  SetOverwrite on
  File /r "${esc(appDir)}/*"
  WriteUninstaller "$INSTDIR\\Uninstall.exe"
  CreateDirectory "$SMPROGRAMS\\Mwendwa Browser"
  CreateShortCut "$SMPROGRAMS\\Mwendwa Browser\\Mwendwa Browser.lnk" "$INSTDIR\\Mwendwa Browser.exe" "" "$INSTDIR\\Mwendwa Browser.exe" 0
  CreateShortCut "$DESKTOP\\Mwendwa Browser.lnk" "$INSTDIR\\Mwendwa Browser.exe" "" "$INSTDIR\\Mwendwa Browser.exe" 0
  WriteRegStr HKCU "Software\\MwendwaBrowser" "InstallDir" "$INSTDIR"
  WriteRegStr HKCU "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MwendwaBrowser" "DisplayName" "Mwendwa Browser"
  WriteRegStr HKCU "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MwendwaBrowser" "DisplayVersion" "1.0.0"
  WriteRegStr HKCU "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MwendwaBrowser" "Publisher" "Mwendwa"
  WriteRegStr HKCU "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MwendwaBrowser" "DisplayIcon" "$INSTDIR\\Mwendwa Browser.exe"
  WriteRegStr HKCU "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MwendwaBrowser" "UninstallString" '"$INSTDIR\\Uninstall.exe"'
  WriteRegDWORD HKCU "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MwendwaBrowser" "NoModify" 1
  WriteRegDWORD HKCU "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MwendwaBrowser" "NoRepair" 1
SectionEnd
Section "Uninstall"
  SetShellVarContext current
  Delete "$DESKTOP\\Mwendwa Browser.lnk"
  Delete "$SMPROGRAMS\\Mwendwa Browser\\Mwendwa Browser.lnk"
  RMDir "$SMPROGRAMS\\Mwendwa Browser"
${deletes}
  Delete "$INSTDIR\\Uninstall.exe"
${removeDirs}
  RMDir "$INSTDIR"
  DeleteRegKey HKCU "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MwendwaBrowser"
  DeleteRegKey HKCU "Software\\MwendwaBrowser"
SectionEnd
`;
// NSIS compile-time macro syntax must remain literal inside the JS template.
const nsisFile=path.join(root,'dist/installer.nsi');fs.writeFileSync(nsisFile,script);const tool=await getMakeNsisPath('1.2.1');const result=spawnSync(tool.path,['-V3',nsisFile],{env:{...process.env,...tool.env},stdio:'inherit'});if(result.status!==0)throw Error('NSIS compilation failed');console.log('Installer ready:',output);})();
